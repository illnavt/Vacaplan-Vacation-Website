tailwind.config = {
    theme: {
        extend: {
           
        }
    }
}