/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.php", "./**/script.js"],
  theme: {
    extend: {},
  },
  plugins: [],
}